%{
#include <stdio.h>
#include <stdlib.h>
#include "ast.h"

extern int yylex();
extern int yylineno;
extern FILE *yyin;
void yyerror(const char *s);

ASTNode* root;
%}

%union {
    int ival;
    double fval;
    char* sval;
    struct _ASTNode* node;
}

%token <ival> INT_CONST
%token <fval> FLOAT_CONST
%token <sval> STRING_CONST
%token <sval> ID
%token INT KW_FLOAT KW_STRING IF ELSE WHILE FOR PRINT

%token EQ NEQ LTE GTE

%type <node> program stmt_list stmt expr decl block
%type <ival> type

/* Precedence and associativity to resolve shift/reduce conflicts */
%right '='
%left EQ NEQ
%left '<' '>' LTE GTE
%left '+' '-'
%left '*' '/'
%nonassoc IFX
%nonassoc ELSE

%%
program:
    stmt_list { root = $1; }
  | /* empty */ { root = NULL; }
    ;

stmt_list:
    stmt { $$ = $1; }
  | stmt_list stmt { $$ = make_seq_node($1, $2); }
  ;

block:
    '{' stmt_list '}' { $$ = $2; }
  | '{' '}' { $$ = NULL; }
  ;

type:
    INT { $$ = VAL_INT; }
  | KW_FLOAT { $$ = VAL_FLOAT; }
  | KW_STRING { $$ = VAL_STRING; }
  ;

stmt:
    decl ';' { $$ = $1; }
  | expr ';' { $$ = $1; }
  | block { $$ = $1; }
  | IF '(' expr ')' stmt %prec IFX { $$ = make_if_node($3, $5, NULL); }
  | IF '(' expr ')' stmt ELSE stmt { $$ = make_if_node($3, $5, $7); }
  | WHILE '(' expr ')' stmt { $$ = make_while_node($3, $5); }
  | FOR '(' decl ';' expr ';' expr ')' stmt { $$ = make_for_node($3, $5, $7, $9); }
  | PRINT '(' expr ')' ';' { $$ = make_print_node($3); }
  ;

decl:
    type ID { $$ = make_decl_node($1, $2, NULL); }
  | type ID '=' expr { $$ = make_decl_node($1, $2, $4); }
  ;

expr:
    ID { $$ = make_id_node($1); }
  | INT_CONST { $$ = make_int_node($1); }
  | FLOAT_CONST { $$ = make_float_node($1); }
  | STRING_CONST { $$ = make_string_node($1); }
  | ID '=' expr { $$ = make_assign_node($1, $3); }
  | expr '+' expr { $$ = make_binop_node('+', $1, $3); }
  | expr '-' expr { $$ = make_binop_node('-', $1, $3); }
  | expr '*' expr { $$ = make_binop_node('*', $1, $3); }
  | expr '/' expr { $$ = make_binop_node('/', $1, $3); }
  | expr '<' expr { $$ = make_binop_node('<', $1, $3); }
  | expr '>' expr { $$ = make_binop_node('>', $1, $3); }
  | expr EQ expr { $$ = make_binop_node(EQ, $1, $3); }
  | expr NEQ expr { $$ = make_binop_node(NEQ, $1, $3); }
  | expr LTE expr { $$ = make_binop_node(LTE, $1, $3); }
  | expr GTE expr { $$ = make_binop_node(GTE, $1, $3); }
  | '(' expr ')' { $$ = $2; }
  ;
%%

void yyerror(const char *s) {
    fprintf(stderr, "Error at line %d: %s\n", yylineno, s);
}
