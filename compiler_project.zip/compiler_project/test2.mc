
for (int j = 0; j < 10; j = j + 1) {
    print(j);
}
