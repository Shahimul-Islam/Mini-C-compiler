int a = 10;
int b = 6;
if (a > 5) {
    b = b + 1.0;
    print(b);
} else {
    print(0);
}