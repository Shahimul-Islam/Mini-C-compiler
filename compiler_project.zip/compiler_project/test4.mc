int x;
x = 5;
if (x > 3) {
    x = x + 1;
    float ab = 10;
 } else {
     x = x - 1;
 }

print(x);