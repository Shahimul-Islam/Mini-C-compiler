int a;
a = 2 + 3 * 4;
int b;
b = 5 + 10 - 10 / 2;

print(a);
print(b);