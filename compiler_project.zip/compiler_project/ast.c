#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ast.h"
#include "parser.tab.h"

// Symbol table limits
#define MAX_SYMBOLS 1000

typedef struct {
    char name[64];
    DataType type;
    union {
        int ival;
        double fval;
        char *sval;
    };
} Symbol;

Symbol sym_table[MAX_SYMBOLS];
int sym_count = 0;

int find_symbol(char *name) {
    for (int i = 0; i < sym_count; i++) {
        if (strcmp(sym_table[i].name, name) == 0) return i;
    }
    return -1;
}

int add_symbol(char *name, DataType type) {
    if (find_symbol(name) != -1) {
        printf("Error: Redeclaration of '%s'\n", name);
        exit(1);
    }
    if (sym_count >= MAX_SYMBOLS) {
        printf("Error: Symbol table full\n");
        exit(1);
    }
    strcpy(sym_table[sym_count].name, name);
    sym_table[sym_count].type = type;
    if (type == VAL_STRING) sym_table[sym_count].sval = NULL;
    else sym_table[sym_count].ival = 0; // initialize zero
    return sym_count++;
}

ASTNode* make_int_node(int val) {
    ASTNode *node = malloc(sizeof(ASTNode));
    node->type = NODE_INT_CONST;
    node->int_val = val;
    return node;
}

ASTNode* make_float_node(double val) {
    ASTNode *node = malloc(sizeof(ASTNode));
    node->type = NODE_FLOAT_CONST;
    node->float_val = val;
    return node;
}

ASTNode* make_string_node(char* val) {
    ASTNode *node = malloc(sizeof(ASTNode));
    node->type = NODE_STRING_CONST;
    node->str_val = strdup(val);
    return node;
}

ASTNode* make_id_node(char* name) {
    ASTNode *node = malloc(sizeof(ASTNode));
    node->type = NODE_ID;
    node->id_name = strdup(name);
    return node;
}

ASTNode* make_decl_node(DataType type, char* name, ASTNode* expr) {
    ASTNode *node = malloc(sizeof(ASTNode));
    node->type = NODE_DECL;
    node->decl.data_type = type;
    node->decl.name = strdup(name);
    node->decl.expr = expr;
    return node;
}

ASTNode* make_assign_node(char* name, ASTNode* expr) {
    ASTNode *node = malloc(sizeof(ASTNode));
    node->type = NODE_ASSIGN;
    node->assign.name = strdup(name);
    node->assign.expr = expr;
    return node;
}

ASTNode* make_binop_node(int op, ASTNode* left, ASTNode* right) {
    ASTNode *node = malloc(sizeof(ASTNode));
    node->type = NODE_BINOP;
    node->binop.op = op;
    node->binop.left = left;
    node->binop.right = right;
    return node;
}

ASTNode* make_if_node(ASTNode* cond, ASTNode* if_branch, ASTNode* else_branch) {
    ASTNode *node = malloc(sizeof(ASTNode));
    node->type = NODE_IF;
    node->if_stmt.cond = cond;
    node->if_stmt.if_branch = if_branch;
    node->if_stmt.else_branch = else_branch;
    return node;
}

ASTNode* make_while_node(ASTNode* cond, ASTNode* body) {
    ASTNode *node = malloc(sizeof(ASTNode));
    node->type = NODE_WHILE;
    node->while_stmt.cond = cond;
    node->while_stmt.body = body;
    return node;
}

ASTNode* make_for_node(ASTNode* init, ASTNode* cond, ASTNode* inc, ASTNode* body) {
    ASTNode *node = malloc(sizeof(ASTNode));
    node->type = NODE_FOR;
    node->for_stmt.init = init;
    node->for_stmt.cond = cond;
    node->for_stmt.inc = inc;
    node->for_stmt.body = body;
    return node;
}

ASTNode* make_print_node(ASTNode* expr) {
    ASTNode *node = malloc(sizeof(ASTNode));
    node->type = NODE_PRINT;
    node->print_stmt.expr = expr;
    return node;
}

ASTNode* make_seq_node(ASTNode* stmt1, ASTNode* stmt2) {
    if (!stmt1) return stmt2;
    if (!stmt2) return stmt1;
    ASTNode *node = malloc(sizeof(ASTNode));
    node->type = NODE_SEQ;
    node->seq.stmt1 = stmt1;
    node->seq.stmt2 = stmt2;
    return node;
}

Value eval(ASTNode* node) {
    Value res = {VAL_INT, {0}};
    if (!node) return res;

    switch(node->type) {
        case NODE_INT_CONST:
            res.type = VAL_INT;
            res.ival = node->int_val;
            break;
        case NODE_FLOAT_CONST:
            res.type = VAL_FLOAT;
            res.fval = node->float_val;
            break;
        case NODE_STRING_CONST:
            res.type = VAL_STRING;
            res.sval = strdup(node->str_val);
            break;
        case NODE_ID: {
            int idx = find_symbol(node->id_name);
            if (idx == -1) {
                printf("Error: Undefined variable '%s'\n", node->id_name);
                exit(1);
            }
            res.type = sym_table[idx].type;
            if (res.type == VAL_INT) res.ival = sym_table[idx].ival;
            else if (res.type == VAL_FLOAT) res.fval = sym_table[idx].fval;
            else res.sval = sym_table[idx].sval ? strdup(sym_table[idx].sval) : strdup("");
            break;
        }
        case NODE_DECL: {
            int idx = add_symbol(node->decl.name, node->decl.data_type);
            if (node->decl.expr) {
                Value val = eval(node->decl.expr);
                if (node->decl.data_type == VAL_INT) {
                    sym_table[idx].ival = (val.type == VAL_FLOAT) ? (int)val.fval : val.ival;
                } else if (node->decl.data_type == VAL_FLOAT) {
                    sym_table[idx].fval = (val.type == VAL_INT) ? (double)val.ival : val.fval;
                } else if (node->decl.data_type == VAL_STRING) {
                    sym_table[idx].sval = val.sval;
                }
            }
            break;
        }
        case NODE_ASSIGN: {
            int idx = find_symbol(node->assign.name);
            if (idx == -1) {
                printf("Error: Undefined variable '%s'\n", node->assign.name);
                exit(1);
            }
            Value val = eval(node->assign.expr);
            if (sym_table[idx].type == VAL_INT) {
                sym_table[idx].ival = (val.type == VAL_FLOAT) ? (int)val.fval : val.ival;
                res.ival = sym_table[idx].ival;
                res.type = VAL_INT;
            } else if (sym_table[idx].type == VAL_FLOAT) {
                sym_table[idx].fval = (val.type == VAL_INT) ? (double)val.ival : val.fval;
                res.fval = sym_table[idx].fval;
                res.type = VAL_FLOAT;
            } else if (sym_table[idx].type == VAL_STRING) {
                if (sym_table[idx].sval) free(sym_table[idx].sval);
                sym_table[idx].sval = val.sval;
                res.sval = val.sval ? strdup(val.sval) : NULL;
                res.type = VAL_STRING;
            }
            break;
        }
        case NODE_BINOP: {
            Value left = eval(node->binop.left);
            Value right = eval(node->binop.right);
            int is_float = (left.type == VAL_FLOAT || right.type == VAL_FLOAT);
            double lval = (left.type == VAL_FLOAT) ? left.fval : (double)left.ival;
            double rval = (right.type == VAL_FLOAT) ? right.fval : (double)right.ival;
            
            res.type = is_float ? VAL_FLOAT : VAL_INT;

            switch(node->binop.op) {
                case '+':
                    if (is_float) res.fval = lval + rval; else res.ival = left.ival + right.ival; break;
                case '-':
                    if (is_float) res.fval = lval - rval; else res.ival = left.ival - right.ival; break;
                case '*':
                    if (is_float) res.fval = lval * rval; else res.ival = left.ival * right.ival; break;
                case '/':
                    if (rval == 0.0 || right.ival == 0) { printf("Error: Division by zero\n"); exit(1); }
                    if (is_float) res.fval = lval / rval; else res.ival = left.ival / right.ival; break;
                case '<':
                    res.type = VAL_INT; res.ival = (lval < rval); break;
                case '>':
                    res.type = VAL_INT; res.ival = (lval > rval); break;
                case EQ:
                    res.type = VAL_INT; res.ival = (lval == rval); break;
                case NEQ:
                    res.type = VAL_INT; res.ival = (lval != rval); break;
                case LTE:
                    res.type = VAL_INT; res.ival = (lval <= rval); break;
                case GTE:
                    res.type = VAL_INT; res.ival = (lval >= rval); break;
            }
            break;
        }
        case NODE_IF: {
            Value cond = eval(node->if_stmt.cond);
            int c = (cond.type == VAL_INT) ? cond.ival : (cond.fval != 0.0);
            if (c) {
                eval(node->if_stmt.if_branch);
            } else if (node->if_stmt.else_branch) {
                eval(node->if_stmt.else_branch);
            }
            break;
        }
        case NODE_WHILE: {
            while (1) {
                Value cond = eval(node->while_stmt.cond);
                int c = (cond.type == VAL_INT) ? cond.ival : (cond.fval != 0.0);
                if (!c) break;
                eval(node->while_stmt.body);
            }
            break;
        }
        case NODE_FOR: {
            if (node->for_stmt.init) eval(node->for_stmt.init);
            while (1) {
                Value cond = eval(node->for_stmt.cond);
                int c = (cond.type == VAL_INT) ? cond.ival : (cond.fval != 0.0);
                if (!c) break;
                eval(node->for_stmt.body);
                if (node->for_stmt.inc) eval(node->for_stmt.inc);
            }
            break;
        }
        case NODE_PRINT: {
            Value val = eval(node->print_stmt.expr);
            if (val.type == VAL_INT) {
                printf("%d\n", val.ival);
            } else if (val.type == VAL_FLOAT) {
                printf("%f\n", val.fval);
            } else if (val.type == VAL_STRING) {
                printf("%s\n", val.sval ? val.sval : "");
            }
            break;
        }
        case NODE_SEQ:
            eval(node->seq.stmt1);
            eval(node->seq.stmt2);
            break;
    }
    return res;
}

void free_ast(ASTNode* node) {
    if (!node) return;
    switch(node->type) {
        case NODE_STRING_CONST:
            free(node->str_val);
            break;
        case NODE_ID:  
            free(node->id_name); 
            break;
        case NODE_DECL:
            free(node->decl.name);
            free_ast(node->decl.expr);
            break;
        case NODE_ASSIGN:
            free(node->assign.name);
            free_ast(node->assign.expr);
            break;
        case NODE_BINOP:
            free_ast(node->binop.left);
            free_ast(node->binop.right);
            break;
        case NODE_IF:
            free_ast(node->if_stmt.cond);
            free_ast(node->if_stmt.if_branch);
            free_ast(node->if_stmt.else_branch);
            break;
        case NODE_WHILE:
            free_ast(node->while_stmt.cond);
            free_ast(node->while_stmt.body);
            break;
        case NODE_FOR:
            free_ast(node->for_stmt.init);
            free_ast(node->for_stmt.cond);
            free_ast(node->for_stmt.inc);
            free_ast(node->for_stmt.body);
            break;
        case NODE_PRINT:
            free_ast(node->print_stmt.expr);
            break;
        case NODE_SEQ:
            free_ast(node->seq.stmt1);
            free_ast(node->seq.stmt2);
            break;
        default:
            break;
    }
    free(node);
}
