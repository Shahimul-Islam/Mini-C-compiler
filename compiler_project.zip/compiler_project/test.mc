string msg = "Hello from string variable!";
print(msg);

// Test variable declaration and assignment
int a = 10;
float b = 3.14;

print(a + b);
print(b);

// Test conditionals and float arithmetic
if (a > 5) {
    print("a is greater than 5");
    b = b + 1.0;
    print(b);
} else {
    print(0);
}

// Test while loop
int i = 0;
while (i < 3) {
    print(i);
    i = i + 1;
}

// Test for loop
for (int j = 0; j < 2; j = j + 1) {
    print(j * 10);
}
