#include <stdio.h>
#include <stdlib.h>
#include "ast.h"

extern FILE *yyin;
extern int yyparse();
extern ASTNode* root;

int main(int argc, char **argv) {
    if (argc > 1) {
        yyin = fopen(argv[1], "r");
        if (!yyin) {
            fprintf(stderr, "Cannot open file %s\n", argv[1]);
            return 1;
        }
    } else {
        printf("Usage: %s <source_file>\n", argv[0]);
        printf("Reading from standard input (Press Ctrl+D to end)...\n\n");
    }

    if (yyparse() == 0) {
        // Evaluate the parsed Abstract Syntax Tree
        eval(root);
        free_ast(root);
    } else {
        fprintf(stderr, "Parsing failed due to syntax errors.\n");
        return 1;
    }
    
    if (yyin && yyin != stdin) {
        fclose(yyin);
    }

    return 0;
}
