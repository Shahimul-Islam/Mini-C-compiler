#ifndef AST_H
#define AST_H

typedef enum {
    VAL_INT,
    VAL_FLOAT,
    VAL_STRING,
    VAL_VOID
} DataType;

typedef enum {
    NODE_INT_CONST,
    NODE_FLOAT_CONST,
    NODE_STRING_CONST,
    NODE_ID,
    NODE_DECL,
    NODE_ASSIGN,
    NODE_BINOP,
    NODE_IF,
    NODE_WHILE,
    NODE_FOR,
    NODE_PRINT,
    NODE_SEQ
} NodeType;

typedef struct _ASTNode {
    NodeType type;
    union {
        int int_val;
        double float_val;
        char *str_val;
        char *id_name;
        
        struct {
            DataType data_type;
            char *name;
            struct _ASTNode *expr;
        } decl;

        struct {
            char *name;
            struct _ASTNode *expr;
        } assign;

        struct {
            int op; // token (+, -, etc.)
            struct _ASTNode *left;
            struct _ASTNode *right;
        } binop;

        struct {
            struct _ASTNode *cond;
            struct _ASTNode *if_branch;
            struct _ASTNode *else_branch;
        } if_stmt;

        struct {
            struct _ASTNode *cond;
            struct _ASTNode *body;
        } while_stmt;

        struct {
            struct _ASTNode *init;
            struct _ASTNode *cond;
            struct _ASTNode *inc;
            struct _ASTNode *body;
        } for_stmt;

        struct {
            struct _ASTNode *expr;
        } print_stmt;

        struct {
            struct _ASTNode *stmt1;
            struct _ASTNode *stmt2;
        } seq;
    };
} ASTNode;

typedef struct {
    DataType type;
    union {
        int ival;
        double fval;
        char *sval;
    };
} Value;

// AST constructors
ASTNode* make_int_node(int val);
ASTNode* make_float_node(double val);
ASTNode* make_string_node(char* val);
ASTNode* make_id_node(char* name);
ASTNode* make_decl_node(DataType type, char* name, ASTNode* expr);
ASTNode* make_assign_node(char* name, ASTNode* expr);
ASTNode* make_binop_node(int op, ASTNode* left, ASTNode* right);
ASTNode* make_if_node(ASTNode* cond, ASTNode* if_branch, ASTNode* else_branch);
ASTNode* make_while_node(ASTNode* cond, ASTNode* body);
ASTNode* make_for_node(ASTNode* init, ASTNode* cond, ASTNode* inc, ASTNode* body);
ASTNode* make_print_node(ASTNode* expr);
ASTNode* make_seq_node(ASTNode* stmt1, ASTNode* stmt2);

// Evaluation and cleanup
Value eval(ASTNode* node);
void free_ast(ASTNode* node);

#endif
