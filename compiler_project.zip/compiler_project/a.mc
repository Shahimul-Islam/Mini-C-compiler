int a = 10;
float b = 3.14;

print(a + b);
